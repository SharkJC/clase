/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication6;
import java.util.Scanner;
import java.io.*;
/**
 *
 * @author LAB-A2
 */
public class JavaApplication6 {
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner entrada = new Scanner(System.in);
       double saldo=85;
       double datos=500;
       char mb;
       double msm=500;
       double credito=100;
       int resp=0;
  
      while(resp != -1){
          System.out.println("__________________________________________"(); 
          System.out.println("1_Consulta tu saldo ");
          System.out.println("2_tranferiri saldo "); 
          System.out.println("3_Pedir saldo");
          resp = entrada.nextInt();
          
        
          
          switch(resp){
              case 1:
                  System.out.println("__________________________________________"); 
                  System.out.println("1-Saldo en Lempiras=" +saldo);
                  System.out.println("2-Datos de navegacion=" +datos +mb);
                  System.out.println("3-Mensajes de Texto=" +msm);
                  break;
                  
              case 2:
                  System.out.println("__________________________________________"); 
                  System.out.println("Cantidad de saldo a Transferir");
                  saldo=saldo-
          }
      }
    
}
